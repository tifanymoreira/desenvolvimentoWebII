<?php
include($_SERVER['DOCUMENT_ROOT'] . '/cjoweb2/central/conexao.php');
include($_SERVER['DOCUMENT_ROOT'] . '/cjoweb2/central/fn/validar_sessao.php');
include($_SERVER['DOCUMENT_ROOT'] . '/cjoweb2/central/fn/menu.php');
?>