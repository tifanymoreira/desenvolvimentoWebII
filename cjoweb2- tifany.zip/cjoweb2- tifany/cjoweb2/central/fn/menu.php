<?php
//$link_cliente_cadastrar = "cliente_cadastrar.php";
//$link_cliente_listar    = "index.php";

$menu_links_clientes = "
	<div class='topnav' id='myTopnav'>
	  <a href='index2.php' class='active'>Home</a>
	  <a href='cliente_cadastrar.php'>Cadastro Cliente</a>
	  <a href='index.php'>Listar Clientes</a>
	  <a href='usuario_cadastrar.php'>Cadastrar Usuário</a>
	  <a href='javascript:void(0);' class='icon' onclick='myFunction()'>
	    <i class='fa fa-bars'></i>
	  </a>
	</div>
";

