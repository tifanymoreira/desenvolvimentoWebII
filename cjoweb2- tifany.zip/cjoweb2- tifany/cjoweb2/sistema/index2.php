<?php
session_start();

var_dump($_SESSION);